function setMax() {
document.getElementById("dateLastPurchased").max = new Date().toLocaleDateString();
}

function cancel() {
  location = "/history";
}

function addNewComment(commentString) {
  var comments = document.getElementById("comment-panel");
  if (comments.children.length < 3) {
    var newRow = document.createElement("div");
    var newComment = document.createElement("textarea");
    if (commentString) {
      newComment.append(commentString);
    }
    var deleteButton = document.createElement("button");
    deleteButton.style.width = "100%";
    newComment.id = "comm" + (comments.children.length + 1);
    newComment.name = newComment.id;
    newComment.placeholder = "*Comment*"
    deleteButton.addEventListener("click", deleteRow)
    deleteButton.appendChild(document.createTextNode("Delete Comment Above"));
    newRow.appendChild(newComment);
    newRow.appendChild(deleteButton);
    comments.appendChild(newRow);
  }
  else {
    alert("Max Comment Number Reached");
  }
}

function deleteRow(event) {
  event.target.parentElement.remove();
}

function addNewLink(linkString) {
  var links = document.getElementById("links-panel");
  if (links.children.length < 3) {
    var newRow = document.createElement("div");
    var newLink = document.createElement("input");
    if (linkString) {
      newLink.value = linkString;
    }
    var deleteButton = document.createElement("button");
    deleteButton.style.marginTop = "1vh";
    deleteButton.style.width = "100%";
    newLink.type = "text";
    newLink.id = "link"+(links.children.length + 1);
    newLink.name = newLink.id;
    newLink.placeholder = "*Link*"
    deleteButton.addEventListener("click", deleteRow);
    deleteButton.appendChild(document.createTextNode("Delete Link Above"));
    newRow.appendChild(newLink);
    newRow.appendChild(deleteButton);
    links.appendChild(newRow);
  }
  else {
    alert("Max Link Number Reached");
  }
}

function setPreview() { // pretty sure this does the same thing as readURL
  if(document.getElementById("profilePic").files[0] && document.getElementById("profilePic").files) {
    var image = document.getElementById("profilePic").files[0];
    if (image.type.startsWith("image/")) {
      var fReader = new FileReader();
      var container = document.getElementById("preview-container");
      // container.classList.add("image-container");
      // container.style.height = "5vh";
      var preview;
      if (container.hasChildNodes()) {
        preview = container.children[0];
      } else {
        preview = document.createElement("img");
      }
      fReader.onload = (e) => {
        preview.src = e.target.result;
        container.appendChild(preview);
      };
      fReader.readAsDataURL(image);
    }
  }
}

function createItem() {
  if (document.getElementById("iName").value.length < 1) {
    alert("Missing Item Name");
  }
  else {
    var itemDetails = new FormData();
    var purchaseDate = document.getElementById("dateLastPurchased").valueAsDate;
    var comments = [];
    var links = [];
  
    for (var i = 1; document.getElementById("comm" + i) != null; i++) {
      comments.push(document.getElementById("comm" + i).value);
    }
    for (var j = 1; document.getElementById("link" + j) != null; j++) {
      links.push(document.getElementById("link" + j).value);
    }
  
    itemDetails.append("ItemName", document.getElementById("iName").value);
    itemDetails.append("Description", document.getElementById("desc").value);
    itemDetails.append("Comments", JSON.stringify(comments));
    itemDetails.append("Links", JSON.stringify(links));
    itemDetails.append("LastPurchased", purchaseDate);
    if (document.getElementById("preview-container").hasChildNodes()) {
      itemDetails.append("ImageDataURL", document.getElementById("preview-container").children[0].src);
    }
  
    var req = new XMLHttpRequest();
    req.open("post", "/items/create");
    req.onload = () => {  
      alert(req.response);
      location = "/history";
    }
    try {
      req.send(itemDetails);
    } catch (err) {
      console.error(err);
    }
    
  }
}

function changePage(newPage) {
  location = newPage;
}