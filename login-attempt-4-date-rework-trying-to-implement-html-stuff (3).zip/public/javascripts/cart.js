function checkout() {
  var req = new XMLHttpRequest();
  req.open("post", "/cart/checkout");
  req.onload = () => {
    alert(req.response);
    location = "/history";
  }
  req.send();
}

function clearCart() {
  var req = new XMLHttpRequest();
  req.open("post", "/cart/clear");
  req.onload = () => {
    alert(req.response);
    location = "/cart";
  }
  req.send();
}

// probably should change the button's icon && function name to show that it removes from cart so it doesnt get confused with an actual profile deletion (maybe like a shopping cart with an arrow pointing out of it)
function deleteItem(rowIndex) {
  var table = document.getElementById("cart-display");
  table.deleteRow(rowIndex);
}

function changePage(newPage) {
  location = newPage;
}