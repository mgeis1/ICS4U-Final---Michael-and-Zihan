function changePage(newPage) {
  location = newPage;
}

function loadHistory() {
  var req = new XMLHttpRequest();
  req.open("post", "/items/load");
  req.responseType = "json";
  req.onload = () => {
    var table = document.getElementsByClassName("transactionTable")[0];
    var row;
    for (var i = 0; req.response[i] != null; i++) {
      if (i % 3 == 0) {
        row = document.createElement("tr");
        table.appendChild(row);
      }
      var cell = document.createElement("td");
      cell.appendChild(makeProfile(req.response[i]));
      row.appendChild(cell);
    }
    
  }
  req.send();
}

function makeProfile(Item) {
  var purchaseDate = new Date(Item.LastPurchased);
  var profile = document.createElement("div");
  profile.classList.add("profile");
  var dateLabel = document.createElement("div");
  dateLabel.classList.add("dateLabel");
  profile.appendChild(dateLabel);
  var date = document.createElement("h3");
  date.append("LAST PURCHASED: " + purchaseDate.toDateString());
  dateLabel.appendChild(date);
  var profileBody = document.createElement("div");
  profileBody.classList.add("profileBody");
  profile.appendChild(profileBody);
  var topSection = document.createElement("div");
  topSection.classList.add("topSection");
  profileBody.appendChild(topSection);
  var bottomSection = document.createElement("div");
  bottomSection.classList.add("bottomSection");
  profileBody.appendChild(bottomSection);
  var imageContainer = document.createElement("div");
  imageContainer.classList.add("imageContainer");
  topSection.appendChild(imageContainer);
  var image = document.createElement("img");
  if (Item.ImageDataURL) {
    image.src = Item.ImageDataURL;
  }
  imageContainer.appendChild(image);
  var mainText = document.createElement("div");
  mainText.classList.add("mainText");
  topSection.appendChild(mainText);
  var ItemName = document.createElement("h4");
  ItemName.append(Item.Name);
  mainText.appendChild(ItemName);
  var description = document.createElement("p");
  description.append(Item.Description); 
  mainText.appendChild(description);
  var comments = document.createElement("div");
  comments.classList.add("comments");
  bottomSection.appendChild(comments);
  var commentLabel = document.createElement("div");
  commentLabel.classList.add("commentLabel");
  commentLabel.append("COMMENTS:");
  comments.appendChild(commentLabel);
  var commentContainer = document.createElement("div");
  commentContainer.classList.add("commentContainer");
  var commentText = document.createElement("pre");
  for (var comment of Item.Comments) {
    commentText.append("" + comment + "\n");
  }
  commentContainer.appendChild(commentText);
  comments.appendChild(commentContainer);
  var links = document.createElement("div");
  links.classList.add("links");
  bottomSection.appendChild(links);
  var linkLabel = document.createElement("div");
  linkLabel.classList.add("linkLabel");
  linkLabel.append("LINKS:");
  links.appendChild(linkLabel);
  var linkContainer = document.createElement("div");
  linkContainer.classList.add("linkContainer");
  var linkText = document.createElement("pre");
  for (var link of Item.Links) {
    linkText.append(""+link+"\n");
  }
  linkContainer.appendChild(linkText);
  links.appendChild(linkContainer);
  var buttonContainer = document.createElement("div");
  buttonContainer.classList.add("buttonContainer");
  bottomSection.appendChild(buttonContainer);
  var cartButton = document.createElement("button");
  cartButton.classList.add("profileButton");
  var cartIcon = document.createElement("img");
  if (Item.InCart) {
    cartIcon.src = "/images/remove-from-cart.png";
    cartButton.onclick = (e) => {
      removeFromCart(e);
    } 
  } else {
    cartIcon.src = "/images/add-to-cart.png";
    cartButton.onclick = (e) => {
      addToCart(e);
    }
  }
  cartButton.appendChild(cartIcon);
  buttonContainer.appendChild(cartButton);
  var editButton = document.createElement("button");
  editButton.classList.add("profileButton");
  var editIcon = document.createElement("img");
  editIcon.src = "/images/qubodup_16x16px-capable_black_and_white_icons_17.png";
  editButton.appendChild(editIcon);
  editButton.onclick = (e) => {
    toUpdatePage(e);
  }
  buttonContainer.appendChild(editButton);
  var deleteButton = document.createElement("button");
  deleteButton.classList.add("profileButton");
  var deleteIcon = document.createElement("img");
  deleteIcon.src = "/images/Trashcan-512.webp";
  deleteButton.appendChild(deleteIcon);
  deleteButton.onclick = (e) => {
    deleteItem(e);
  }
  buttonContainer.appendChild(deleteButton);
  return profile;
}

function addToCart(e) {
  var id = e.target.parentNode.parentNode.parentNode.parentNode.children[0].children[1].children[0].innerHTML.split(/\s/).join("-");
  var req = new XMLHttpRequest();
  req.open("post", "/cart/add?id="+id);
  req.onload = () => {
    alert(req.response);
    location = "/history";
  }
  req.send();
}

function removeFromCart(e) {
  var id = e.target.parentNode.parentNode.parentNode.parentNode.children[0].children[1].children[0].innerHTML.split(/\s/).join("-");
  var req = new XMLHttpRequest();
  req.open("post", "/cart/remove?id="+id);
  req.onload = () => {
    alert(req.response);
    location = "/history";
  }
  req.send();
}

function toUpdatePage(e) {
  var id = e.target.parentNode.parentNode.parentNode.parentNode.children[0].children[1].children[0].innerHTML.split(/\s/).join("-");
  location = "/items/update?id="+id;
}

function deleteItem(e) {
  var name = e.target.parentNode.parentNode.parentNode.parentNode.children[0].children[1].children[0].innerHTML;
  var id = name.split(/\s/).join("-");
  if (confirm("Are you sure you want to delete "+name+"'s profile?")) {
    var req = new XMLHttpRequest();
    req.open("post", "/items/delete?id="+id);
    req.onload = () => {
      alert(req.response);
      location = "/history";
    }
    req.send();
  }
}