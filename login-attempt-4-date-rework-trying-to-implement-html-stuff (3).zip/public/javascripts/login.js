function registerAccount() {
  var accountIN = new FormData();
  accountIN.append("Username", document.getElementById("user").value);
  accountIN.append("Password", document.getElementById("pass").value);
  
  var req = new XMLHttpRequest();
  req.open("post", "/accounts/register");
  req.onload = () => {
    if (req.response == "success") {
      alert("Account registered successfully, proceed to main page");
      location = "/history";
    } else {
      alert(req.response);
    }
  }
  req.send(accountIN);
}

function verifyAccount() {
  var accountIN = new FormData();
  accountIN.append("Username", document.getElementById("user").value);
  accountIN.append("Password", document.getElementById("pass").value);

  var req = new XMLHttpRequest();
  req.open("post", "/accounts/login");
  req.onload = () => {
    if (req.response == "success") {
      alert("Logged in successfully, proceed to main page");
      location = "/history";
    } else {
      alert(req.response);
    }
  }
  req.send(accountIN);
}
